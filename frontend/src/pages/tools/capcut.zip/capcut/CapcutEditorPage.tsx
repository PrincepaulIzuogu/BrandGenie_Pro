import React, { useState } from 'react';
import Sidebar, { TabName } from './components/Sidebar';
import ToolControls from './components/ToolControls';
import UploadPanel from './components/UploadPanel';
import EditorCanvas from './components/EditorCanvas';

const CapcutEditorPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabName>('Media');
  const [selectedTool, setSelectedTool] = useState<'cut' | 'text' | 'filter' | null>(null);
  const [selectedClip, setSelectedClip] = useState<{
    id: string;
    name: string;
    type: 'video' | 'image' | 'audio';
    url: string;
  } | null>(null);

  const handleUpload = (files: File[]) => {
    const first = files[0];
    if (!first) return;
    const fileUrl = URL.createObjectURL(first);
    const type = first.type.startsWith('video')
      ? 'video'
      : first.type.startsWith('image')
      ? 'image'
      : 'audio';
    setSelectedClip({
      id: Date.now().toString(),
      name: first.name,
      type,
      url: fileUrl,
    });
  };

  return (
    <div className="flex h-screen bg-white">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="flex flex-col flex-1">
        <div className="flex flex-col border-b border-gray-300">
          <ToolControls selectedTool={selectedTool} />
        </div>
        <div className="flex flex-1 overflow-hidden">
          <div className="w-1/4 border-r border-gray-300 bg-gray-900">
            <UploadPanel onFileSelect={handleUpload} />
          </div>
          <div className="flex-1 bg-gray-100 p-4">
            <EditorCanvas selectedClip={selectedClip} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CapcutEditorPage;
