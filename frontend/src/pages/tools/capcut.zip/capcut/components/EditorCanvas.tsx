import React, { useRef, useEffect } from 'react';

export interface EditorCanvasProps {
  selectedClip: {
    id: string;
    name: string;
    type: 'video' | 'image' | 'audio';
    url: string;
  } | null;
}

const EditorCanvas: React.FC<EditorCanvasProps> = ({ selectedClip }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (selectedClip?.type === 'video' && videoRef.current) {
      videoRef.current.load();
    }
    if (selectedClip?.type === 'audio' && audioRef.current) {
      audioRef.current.load();
    }
  }, [selectedClip]);

  return (
    <div className="flex items-center justify-center w-full h-[400px] bg-black border border-gray-700 rounded-lg overflow-hidden relative">
      {!selectedClip ? (
        <p className="text-gray-500">Select or upload a clip to preview</p>
      ) : selectedClip.type === 'video' ? (
        <video ref={videoRef} controls className="max-w-full max-h-full">
          <source src={selectedClip.url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      ) : selectedClip.type === 'image' ? (
        <img src={selectedClip.url} alt={selectedClip.name} className="max-w-full max-h-full object-contain" />
      ) : selectedClip.type === 'audio' ? (
        <audio ref={audioRef} controls className="absolute bottom-4 left-4 right-4">
          <source src={selectedClip.url} type="audio/mpeg" />
          Your browser does not support the audio tag.
        </audio>
      ) : null}
    </div>
  );
};

export default EditorCanvas;
