import React, { useRef, useState } from 'react';

interface UploadPanelProps {
  onFileSelect: (files: File[]) => void;
}

const UploadPanel: React.FC<UploadPanelProps> = ({ onFileSelect }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setSelectedFiles(files);
      onFileSelect(files);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex flex-col items-center justify-center h-full w-full px-6 py-8 text-center text-white">
      <div
        onClick={triggerFileInput}
        className="w-full h-48 border-2 border-dashed border-gray-500 flex flex-col items-center justify-center rounded-lg cursor-pointer hover:border-blue-500 transition"
      >
        <p className="text-sm text-gray-300">Drag & drop files here or</p>
        <button className="text-blue-400 font-medium mt-2">Click to upload</button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,image/*,audio/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />

      {selectedFiles.length > 0 && (
        <div className="w-full mt-6 grid grid-cols-3 gap-4">
          {selectedFiles.map((file, index) => (
            <div
              key={index}
              className="border border-gray-600 rounded p-2 text-xs truncate text-gray-300 bg-gray-800"
            >
              {file.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UploadPanel;
