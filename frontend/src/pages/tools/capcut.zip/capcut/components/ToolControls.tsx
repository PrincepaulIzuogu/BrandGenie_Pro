import React from 'react';

export interface ToolControlsProps {
  selectedTool: 'cut' | 'text' | 'filter' | null;
}

const ToolControls: React.FC<ToolControlsProps> = ({ selectedTool }) => {
  return (
    <div className="flex px-4 py-2 bg-gray-100">
      <span className="text-sm text-gray-600">Selected Tool: </span>
      <span className="ml-2 font-medium text-gray-800">{selectedTool || 'None'}</span>
    </div>
  );
};

export default ToolControls;
